package ufs.br.poostore.consts;

/**
 *
 * @author isaac
 */
public enum User {
    CAIXA,
    GESTOR_ESTOQUE,
    GESTOR_CLIENTE,
    GERENTE
}
