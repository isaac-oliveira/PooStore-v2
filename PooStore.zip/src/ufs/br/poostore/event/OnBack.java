/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ufs.br.poostore.event;

import ufs.br.poostore.consts.User;

/**
 *
 * @author victor
 */
public interface OnBack {
    public void onBackPressed(User user);
}
