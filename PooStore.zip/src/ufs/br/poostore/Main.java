package ufs.br.poostore;

import ufs.br.poostore.views.MainScreen;

/**
 *
 * @author isaac
 */
public class Main {
    
    public static void main(String args[]) {
        new MainScreen().setVisible(true);               
    }
}
